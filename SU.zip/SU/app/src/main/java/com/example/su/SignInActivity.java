package com.example.su;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SignInActivity extends AppCompatActivity {

    Button googleSignInButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_in);

        googleSignInButton = findViewById(R.id.google_sign_in_button);
        googleSignInButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                if(signInWithGoogle()){
                    //Move to the next Activity
                }
                else{
                    displaySignInFailedSnackbar();
                }
            }
        });
    }

    //This method is called when the "sign in with Google" button is tapped. Add the auhtentication code here. Return false if sign in fails and a dialog will be shown saying that the sign in failed.
    private boolean signInWithGoogle(){

        return false;
    }

    private void displaySignInFailedSnackbar(){

    }
}
